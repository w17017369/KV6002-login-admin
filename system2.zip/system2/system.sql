/*
 Navicat Premium Data Transfer

 Source Server         : 127.0.0.1
 Source Server Type    : MySQL
 Source Server Version : 50726
 Source Host           : 127.0.0.1:3306
 Source Schema         : system

 Target Server Type    : MySQL
 Target Server Version : 50726
 File Encoding         : 65001

 Date: 25/04/2022 22:36:03
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cc_address_info
-- ----------------------------
DROP TABLE IF EXISTS `cc_address_info`;
CREATE TABLE `cc_address_info`  (
  `address_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `address` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `userid` int(10) NULL DEFAULT NULL,
  `tel_phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `receiver_name` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`address_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cc_address_info
-- ----------------------------
INSERT INTO `cc_address_info` VALUES (1, '广东深圳南山', 33, '13800138000', '程序员');

-- ----------------------------
-- Table structure for cc_admin
-- ----------------------------
DROP TABLE IF EXISTS `cc_admin`;
CREATE TABLE `cc_admin`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `adminuser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `adminpass` char(52) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `created_at` int(11) NOT NULL DEFAULT 0,
  `login_at` int(11) NOT NULL DEFAULT 0,
  `login_ip` bigint(3) NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'Backend Management Form' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of cc_admin
-- ----------------------------
INSERT INTO `cc_admin` VALUES (11, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 1795162113, 1795162113, 1795162113);

-- -- ----------------------------
-- -- Table structure for cc_cart
-- -- ----------------------------
-- DROP TABLE IF EXISTS `cc_cart`;
-- CREATE TABLE `cc_cart`  (
--   `Id` int(11) NOT NULL AUTO_INCREMENT,
--   `uid` int(11) UNSIGNED NOT NULL DEFAULT 0,
--   `price` decimal(10, 2) UNSIGNED NOT NULL DEFAULT 0.00,
--   `quantity` int(11) UNSIGNED NOT NULL DEFAULT 0,
--   `products` int(11) NOT NULL,
--   `status` int(11) NOT NULL DEFAULT 0 COMMENT '0 Unpaid 1 Payment',
--   `created_at` int(11) NOT NULL DEFAULT 0,
--   PRIMARY KEY (`Id`) USING BTREE
-- ) ENGINE = MyISAM AUTO_INCREMENT = 21 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- -- ----------------------------
-- -- Records of cc_cart
-- -- ----------------------------
-- INSERT INTO `cc_cart` VALUES (17, 33, 123.00, 3, 28, 1, 1647361002);
-- INSERT INTO `cc_cart` VALUES (19, 7, 3.00, 3, 26, 3, 1647361436);
-- INSERT INTO `cc_cart` VALUES (20, 7, 3.00, 2, 26, 1, 1647617259);

-- ----------------------------
-- Table structure for cc_Newsletter
-- ----------------------------
DROP TABLE IF EXISTS `cc_Newsletter`;
CREATE TABLE `cc_Newsletter`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标题',
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of cc_Newsletter
-- ----------------------------
INSERT INTO `cc_Newsletter` VALUES (1, '123', '新年快乐，新年大吉！！！！！！！', 0, 1647357339);
INSERT INTO `cc_Newsletter` VALUES (2, '123', '13123', 1647357246, NULL);

-- ----------------------------
-- Table structure for cc_mess
-- ----------------------------
DROP TABLE IF EXISTS `cc_mess`;
CREATE TABLE `cc_mess`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'user id',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 48 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'Message Board List' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of cc_mess
-- ----------------------------

INSERT INTO `cc_mess` VALUES (43, 33, '21312', '123123', 1647358457);
INSERT INTO `cc_mess` VALUES (42, 33, '21312', '123123', 1647358422);
INSERT INTO `cc_mess` VALUES (41, 33, '21312', '123123', 1647358411);
INSERT INTO `cc_mess` VALUES (40, 33, '21321', '123123', 1647358384);

-- ----------------------------
-- Table structure for cc_order
-- ----------------------------
DROP TABLE IF EXISTS `cc_order`;
CREATE TABLE `cc_order`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(10, 2) UNSIGNED NOT NULL DEFAULT 0.00,
  `Deposit` float(10, 2) NULL DEFAULT 0.00 COMMENT 'Deposit',
  `quantity` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `products` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `uid` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` int(11) NULL DEFAULT 0,
  `address` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
  `status` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'Not Out Of Stock',
  `address_id` int(10) NULL DEFAULT NULL COMMENT 'User Address ID',
  `order_no` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'Order Number',
  `pay_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Payment Status - 1=Refunded,0=Pending,1=Paid,2=Delivered,3=Completed',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Order Message',
  `delivery_company` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Courier companies',
  `postage` float(10, 2) NULL DEFAULT NULL COMMENT 'Freight charges',
  `paymenttime` datetime NULL DEFAULT NULL COMMENT 'payment time',
  `sendtime` datetime NULL DEFAULT NULL COMMENT 'send time',
  `endtime` datetime NULL DEFAULT NULL COMMENT 'end time',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 39 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of cc_order
-- ----------------------------
INSERT INTO `cc_order` VALUES (37, 123.00, 0.00, 2, '28', 33, 1647362894, 'xxx street', 'Out Of Stock', NULL, 'B202204242318', 1, '私密发货', 'UPS', 9.90, '2022-04-25 21:48:30', '2022-04-15 21:55:07', '2022-04-12 21:55:15');
INSERT INTO `cc_order` VALUES (38, 123.00, 0.00, 2, '28', 33, 1647363075, 'xxx street', 'Out Of Stock', NULL, 'B202204242012', -1, '私密发货', 'UPS', 9.90, '2022-04-25 21:48:35', '2022-04-20 21:55:11', '2022-04-21 21:55:19');

-- -- ----------------------------
-- -- Table structure for cc_pinglun
-- -- ----------------------------
-- DROP TABLE IF EXISTS `cc_pinglun`;
-- CREATE TABLE `cc_pinglun`  (
--   `id` int(11) NOT NULL AUTO_INCREMENT,
--   `mid` int(11) NOT NULL COMMENT '帖子id',
--   `uid` int(11) NOT NULL COMMENT '评论用户id',
--   `content` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '评论内容',
--   `create_time` int(11) NOT NULL COMMENT '评论时间',
--   PRIMARY KEY (`id`) USING BTREE
-- ) ENGINE = MyISAM AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- -- ----------------------------
-- -- Records of cc_pinglun
-- -- ----------------------------
-- INSERT INTO `cc_pinglun` VALUES (1, 28, 33, '123', 1647359664);

-- ----------------------------
-- Table structure for cc_products
-- ----------------------------
DROP TABLE IF EXISTS `cc_products`;
CREATE TABLE `cc_products`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `tid` int(11) NOT NULL COMMENT 'Category ID',
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `stock` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `price` decimal(10, 2) UNSIGNED NOT NULL DEFAULT 0.00,
  `created_at` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `img_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `image` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'Product Main Image',
  `subtitle` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'subtitle',
  `updatetime` datetime NULL DEFAULT NULL COMMENT 'Update time',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 30 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of cc_products
-- ----------------------------
INSERT INTO `cc_products` VALUES (17, '菠菜', '11-1-2', 6, '冬季。春季沙土地小叶菠菜基地直供区。本处菠菜品种有:名门菠菜。黑叶菠菜。宝来菠菜。小叶菠菜。绿皇后。等精品菠菜种。本处小叶菠菜有柳叶菠菜。尖耳朵菠菜。耐看受卖。本处菠菜总面积达20000亩产区。覆盖整个高青县种植区。种植时间为每年9-5月采购种植。本处提供泡沫箱包装。本处提供泡沫箱。包装纸。包装袋。冰瓶。割菜工。', 0, 12.00, '2022-02-24 17:03:43', 'upload/16456934231.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (18, '大葱', '11-2-3', 6, '  大葱产地批发长期供应铁杆大葱长白大葱净葱代加工净葱货源集中质量保证欢迎咨询\r\n\r\n    联系我时请说明是在 农产品信息网 上看到的，谢谢！', 0, 11.00, '2022-02-24 17:05:46', 'upload/16456935462.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (19, '香蒜苗', '10-2-1', 6, '这里是产香蒜苗（红根）产源地,每年这里都种植有万亩南方香蒜苗，现在是丰盛季节，香蒜苗与大蒜是不一样的，香蒜苗要比大蒜的味道还要香浓郁，清香、美味、杀菌能力强，现在蒜种即将上市，目前老百姓大量的面积香蒜苗已经上市，主要是没有销路的渠道，如果有眼光的市场前景赚钱的老板，前来查看与收\r\n    购', 0, 5.00, '2022-02-24 17:10:03', 'upload/16456938033.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (20, '[供]园林绿化草坪草籽边坡植草绿化工程草种', '20-2-1', 10, '    供应各种绿化工程草籽，结缕草，狗牙根，马尼拉，百慕大，黑麦草，高羊茅，早熟禾，剪股颖等。', 0, 2.00, '2022-02-24 21:07:10', 'upload/16457080304.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (21, '[供]红油蟠黄蟠黄桃树苗价格泰安供应新品种桃树苗', '98-2-3', 10, '我苗圃大量供应桃树嫁接苗，品种映霜红，红油蟠，黄油蟠，突围，黑桃，风味皇后，春雪，福桃，中华寿桃等，品种纯正无病虫害，苗圃批发直销。', 0, 56.00, '2022-02-24 21:15:27', 'upload/16457085275.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (22, '[供]欧凯儿秋葵种子极早熟品种', '2-3-1-1', 10, '&ldquo;欧凯儿&rdquo;秋葵种子&mdash;&mdash;早熟，适合早春抢早栽培，连续坐果性好，早期产量高。春季前期耐寒，生长中后期耐热，生长势强，叶片大，后劲足，植株顶端不容易&ldquo;秃头&rdquo;。植株节间短，果长11-12公分、果肩膀直径1.7-1.8公分为适收期，果翠绿色且富有光泽，萼片不易脱落，脆嫩清甜，迎合高端消费需求。果实耐贮运，长途运输棱角不易变黑。抗逆性好，连阴雨天不易落花落果，整个生长期&ldquo;黄尾巴&rdquo;和&ldquo;白果&rdquo;现象少。果实整齐度好，商品性优，大大降低了采摘及选果包装的操作难度。', 0, 6.00, '2022-02-24 21:17:13', 'upload/16457086336.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (23, '[供]长年供应各种花椒苗', '1-6-9', 10, ' 九叶青；大红袍；贡椒。以及各种品种！', 0, 7.00, '2022-02-24 21:19:45', 'upload/16457087857.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (24, '[供]春花生产地生长周期长，出米率70%一80%利润高', '2-9-8', 8, '联系站点\r\n', 0, 1.00, '2022-02-24 21:23:47', 'upload/16457090278.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (25, '[供]黑豆，适合煮粥用的黑豆', '5-98-7', 8, ' 培公粮油注重产品品质，坚贞不渝为您提供上天赐予人们的天然食材而非人工合成的食材！！！！\r\n    丹曦黑豆 厂家直销\r\n    【包装】真空包装4斤装！\r\n    【发货方式】包邮\r\n    【出售形式】批发、零售，支持电商直播采购。\r\n    【产品产地】黑龙江省哈尔滨市\r\n    【产品特点】劲道可口。\r\n    【食用方法】适合煮粥饭\r\n    【售后服务】请确认完好无损后签收，米质量问题收到货后24小时内及时联系客服。\r\n    【合作介绍】黑龙江培公粮油有限公司，现面向全国各地诚招经销商和合作伙伴，货源充足、质量可靠、保质保量、保真保纯，同时为电商、微商、提供一件代发。\r\n    常年生产，包装可根据客户需要选择白包装或者彩包装，本价格不含发票\r\n    \r\n    平台卖家销售货品如出现规格不符、霉变、损耗过高、少量等情况，请在收到货品后即时向卖家发起售后，卖家将在第一时间进行处理；其中物流费用、提货点及售后方式以买卖双方协商约定为准。 如双方多次协商无法达成一致，可申请平台客服介入处理', 0, 1.00, '2022-02-24 21:26:22', 'upload/16457091829.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (26, '[供]燕麦米，世界公认的营养价值超高的杂粮', '2-2-3-4', 8, '培公粮油注重产品品质，坚贞不渝为您提供上天赐予人们的天然食材而非人工合成的食材！！！！\r\n    丹曦燕麦米 厂家直销\r\n    【包装】真空包装5斤装！\r\n    【发货方式】48小时内发货包邮，（新疆、西藏、港澳台除外）量大客服咨询。\r\n    【出售形式】批发、零售，支持电商直播采购。\r\n    【产品产地】黑龙江省哈尔滨市五常市\r\n    【产品特点】有清淡的、自然香味\r\n    【食用方法】煮粥，燕麦片\r\n    【售后服务】请确认完好无损后签收，米质量问题收到货后24小时内及时联系客服。\r\n    【合作介绍】黑龙江培公粮油有限公司，现面向全国各地诚招经销商和合作伙伴，货源充足、质量可靠，保质保量、保真保纯、可提供发票，同时为电商、微商、各种平台提供一件代发。\r\n    平台卖家销售货品如出现规格不符、霉变、损耗过高、少量等情况，请在收到货品后即时向卖家发起售后，卖家将在第一时间进行处理；其中物流费用、提货点及售后方式以买卖双方协商约定为准。 如双方多次协商无法达成一致，可申请平台客服介入处理', 0, 3.00, '2022-02-24 21:28:24', 'upload/164570930410.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (27, 'ceshi', '11231', 11, '123123', 0, 123.00, '2022-03-15 23:00:16', 'upload/1647356416微信图片_20220304154357.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (28, 'ceshi', '11-231', 11, '123123', 0, 123.00, '2022-03-15 23:00:46', 'upload/1647356446微信图片_20220304154357.jpg', NULL, NULL, NULL);
INSERT INTO `cc_products` VALUES (29, '1123212', '11-32123123', 11, '1231221323', 0, 2122.00, '2022-03-15 23:01:01', 'upload/1647356461300046-106.jpg', NULL, NULL, NULL);

-- ----------------------------
-- Table structure for cc_type
-- ----------------------------
DROP TABLE IF EXISTS `cc_type`;
CREATE TABLE `cc_type`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'Name',
  `create_time` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'Type of product' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of cc_type
-- ----------------------------
INSERT INTO `cc_type` VALUES (8, '粮油', 1645693112);
INSERT INTO `cc_type` VALUES (7, '水果', 1645693107);
INSERT INTO `cc_type` VALUES (6, '蔬菜', 1645693102);
INSERT INTO `cc_type` VALUES (9, '畜牧养殖', 1645693118);
INSERT INTO `cc_type` VALUES (10, '种子农资', 1645693130);
INSERT INTO `cc_type` VALUES (11, '其他农副12', 1645693158);

-- ----------------------------
-- Table structure for cc_user
-- ----------------------------
DROP TABLE IF EXISTS `cc_user`;
CREATE TABLE `cc_user`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `password` char(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `day` int(11) NOT NULL COMMENT 'Date of Birth',
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `update_time` int(11) NULL DEFAULT NULL,
  `created_at` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 34 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'User Form' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of cc_user
-- ----------------------------
INSERT INTO `cc_user` VALUES (7, '123', 'e10adc3949ba59abbe56e057f20f883e', 0, '', '', 1610382415, 1610331402);
INSERT INTO `cc_user` VALUES (13, '666', 'fae0b27c451c728867a567e8c1bb4e53', 0, '614141873@qq.com', '13581996629', NULL, 1610436355);
INSERT INTO `cc_user` VALUES (26, '1', 'c4ca4238a0b923820dcc509a6f75849b', 0, '614141873@qq.com', 'phone', NULL, 1610440956);
INSERT INTO `cc_user` VALUES (27, '2', 'c81e728d9d4c2f636f067f89cc14862c', 0, '', '13581996629', 1610441331, 1610441314);
INSERT INTO `cc_user` VALUES (28, '3', '202cb962ac59075b964b07152d234b70', 0, '', '13581996629', 1610442669, 1610442642);
INSERT INTO `cc_user` VALUES (29, '4', 'a87ff679a2f3e71d9181a67b7542122c', 0, '614141873@qq.com', 'phone', NULL, 1610443047);
INSERT INTO `cc_user` VALUES (30, '5', '202cb962ac59075b964b07152d234b70', 0, '614141873@qq.com', '13581996629', 1610443128, 1610443106);
INSERT INTO `cc_user` VALUES (32, '1234', '81dc9bdb52d04dc20036dbd8313ed055', 0, '15992389958@qq.com', 'phone', NULL, 1638887821);
INSERT INTO `cc_user` VALUES (33, '12333', 'a8ae104615cb4e966ddb435f3e575a02', 1647446400, '12345621@qq.com', '13042781123', NULL, 1647271474);



-- -- ----------------------------
-- -- Table structure for liuyan
-- -- ----------------------------
-- DROP TABLE IF EXISTS `liuyan`;
-- CREATE TABLE `liuyan`  (
--   `id` int(11) NOT NULL AUTO_INCREMENT,
--   `tid` int(11) NOT NULL,
--   `uid` int(11) NULL DEFAULT 0,
--   `pid` int(11) NULL DEFAULT 0,
--   `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
--   `create_time` int(11) NOT NULL,
--   `img` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
--   PRIMARY KEY (`id`) USING BTREE
-- ) ENGINE = MyISAM AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- -- ----------------------------
-- -- Records of liuyan
-- -- ----------------------------
-- INSERT INTO `liuyan` VALUES (1, 1, 7, 7, '123123', 1604246400, 'images/1649673060.jpg');
-- INSERT INTO `liuyan` VALUES (2, 1, 7, 7, '123', 1648393948, 'images/1649673060.jpg');
-- INSERT INTO `liuyan` VALUES (3, 1, 0, 0, '123', 1649673060, 'images/1649673060.jpg');
-- INSERT INTO `liuyan` VALUES (4, 1, 0, 0, '11111', 1649673240, 'images/1649673240.jpg');
-- INSERT INTO `liuyan` VALUES (5, 1, 0, 0, '111', 1649675884, 'images/1649675884.jpg');
-- INSERT INTO `liuyan` VALUES (6, 1, 0, 0, 'sssss', 1649675997, 'images/1649675997.jpg');

-- -- ----------------------------
-- -- Table structure for tiezi
-- -- ----------------------------
-- DROP TABLE IF EXISTS `tiezi`;
-- CREATE TABLE `tiezi`  (
--   `id` int(11) NOT NULL AUTO_INCREMENT,
--   `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
--   `content` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
--   `uid` int(11) NOT NULL,
--   `create_time` int(11) NOT NULL,
--   PRIMARY KEY (`id`) USING BTREE
-- ) ENGINE = MyISAM AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- -- ----------------------------
-- -- Records of tiezi
-- -- ----------------------------
-- INSERT INTO `tiezi` VALUES (1, '1212111', '1222212121', 7, 1604246400);

-- SET FOREIGN_KEY_CHECKS = 1;

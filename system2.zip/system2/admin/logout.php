<?php 

require '../toos.func.php';


deleteSession('admin');
header('location:login.php');

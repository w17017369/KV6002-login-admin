
<?php
require '../db.func.php';
require '../toos.func.php';
require 'auth.php';
$prefix = getDBPregix();
if(empty($_POST['name'])){
$sql ="SELECT id,name,code,tid,description,stock,price,created_at
      FROM {$prefix}products ORDER BY created_at DESC";
}else{
	$name = $_POST['name'];
	$sql ="SELECT id,name,code,tid,description,stock,price,created_at
	      FROM {$prefix}products WHERE name like '%$name%' ORDER BY created_at DESC";
}
$res=query($sql);  
function type($tid){
	$prefix = getDBPregix();
	$sqll ="SELECT id,name
	      FROM {$prefix}type WHERE id = '$tid' ";
	$ress=queryOne($sqll);
	echo $ress['name'];
}

require 'header.php';
?>


      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <div class="row">
                    <div class="col-10">
                      <h4 class="card-title ">All products</h4>
                    </div>
                    <div class="col-2">
                      <a href="product_add.php" class="btn btn-round btn-info" style="margin-left: 20px;">Add product</a>
					  
                    </div>
                  </div>

                </div>
                <div class="card-body">
					<p style="color: red;"><?php if(hasInfo()) echo getInfo(); ?></p>
                  <div class="table-responsive">
					  <form action="" method="post">
						  <input name="name" placeholder="Enter product name" />
						  <input type="submit" />
					  </form>
                    <table class="table table-hover">
                      <thead class=" text-primary">
                      <th>
                        No.
                      </th>
                      <th>
                        Name
                      </th>
					             <th>
					              Category
					             </th>
                      <th>
                        Description
                      </th>
                      <th>
                        Inventory
                      </th>
                      <th>
                        Price
                      </th>
                      <th>
                        Create time
                      </th>
                      <th>
                      
                      </th>
                      </thead>
                      <tbody>
					  <?php foreach($res as $products): ?>
                      <tr>
                        <td>
                          <?php echo $products['code']; ?>
                        </td>
                        <td>
                          <?php echo $products['name']; ?>
                        </td>
						<td>
						  <?php  type($products['tid']);  ?>
						</td>
                        <td>
                          <?php echo $products['description']; ?>
                        </td>
                        <td>
                          <?php echo $products['stock']; ?>
                        </td>
                        <td>
                          <?php echo $products['price']; ?>
                        </td>
                        <td>
                          <?php echo $products['created_at']; ?>
                        </td>
                        <td>
                          <a href="product_edit.php?id=<?php echo $products['id']; ?>">Edit</a>
                          |
						
                          <a href="javascript:if(confirm('Confitm Delete?')) location='product_del.php?id=<?php echo $products['id']; ?>'">Delete</a>
                        </td>
                      </tr>
					  <?php endforeach ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
   <?php 
   require 'footer.php';
   ?>
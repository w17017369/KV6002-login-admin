<?php 
require '../db.func.php';
require '../toos.func.php';
session_start();
$uid =$_SESSION['user']['id'];
 $prefix = getDBPregix();
 $sql = "SELECT id,price,quantity,uid,created_at,status,products
         FROM {$prefix}cart WHERE uid = {$uid} ORDER BY created_at DESC";
$cart=query($sql);
require 'header.php';
?>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <div class="row">
                    <div class="col-12">
                      <h4 class="card-title ">Favourates</h4>
          
                    </div>
                  </div>

                </div>
                <div class="card-body">
                  <div class="table-responsive">
					  	<p style="color: red;"><?php if(hasInfo()) echo getInfo(); ?></p>
                    <table class="table table-hover">
                      <thead class=" text-primary">
                      <th>
                        ID
                      </th>
					  <th>
					    Name
					  </th>
                      <th>
                        Number
                      </th>
                      <th>
                        Price
                      </th>
                      <th>
                        Time add
                      </th>
                      <th>
                        Edit
                      </th>
                      </thead>
                      <tbody>
					<?php foreach($cart as $c): ?>
                      <tr>
                        <td>
                         <?php echo $c['id'] ?>
                        </td>
						<td>
						 <?php 
						 //查询商品 名称
						  $pid =   $c['products'];
						 //  var_dump($pid);die;
						 $sql = "select * from cc_products where id={$pid} ";
						
						$res =  queryOne($sql);
						 echo $res['name'] ?>
						</td>
                        <td>
                          <?php echo $c['quantity'] ?>
                        </td>
                        <td>
                          <?php echo $c['price'] ?>
                        </td>
                        <td>
                          <?php echo date('Y-m-d',$c['created_at']) ?>
                        </td>
                        <td>
                          <a href= "javascript:if(confirm('确定删除吗?')) location='carts_del.php?id=<?php echo  $c['id']?>'">Delete</a>
                        </td>
						<?php endforeach; ?>
                      </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    
	<?php
	require 'footer.php';
	?>
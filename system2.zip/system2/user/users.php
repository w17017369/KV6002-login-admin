<?php
require '../db.func.php';
require '../toos.func.php';
require 'auth.php';
$prefix = getDBPregix();
$sql ="SELECT id,username,email,phone,day ,created_at
      FROM {$prefix}user ORDER BY created_at DESC";
$res=query($sql);  
require 'header.php';
?>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <div class="row">
                    <div class="col-10">
                      <h4 class="card-title ">All users</h4>
                      <p class="card-category"> User list</p>
                    </div>
                    <div class="col-2">
                      <a href="user_add.php" class="btn btn-round btn-info" style="margin-left: 20px;">Add users</a>
                    </div>
                  </div>
                </div>
                <div class="card-body">
					<p style="color: red;"><?php if(hasInfo()) echo getInfo(); ?></p>
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead class=" text-primary">
                      <th>
                        ID
                      </th>
                      <th>
                        User Name
                      </th>
                      <th>
                        E-mail
                      </th>
                      <th>
                        Contact
                      </th>
                      <th>
                        Registered Time
                      </th>
                      <th>
                        Opreation
                      </th>
                      </thead>
                      <tbody>
					<?php foreach($res as $user): ?>
                      <tr>
                        <td>
                          <?php echo $user['id']; ?>
                        </td>
                        <td>
                          <?php echo $user['username']; ?>
                        </td>
                        <td>
                          <?php echo $user['email']; ?>
                        </td>
                        <td>
                          <?php echo $user['phone']; ?>
                        </td>
                        <td>
                          <?php echo date('Y-m-d',$user['created_at']); ?>
                        </td>
                        <td>
                          <a href="user_edit.php?id=<?php echo $user['id']; ?>">Edit</a>
                          |
                          <a href="javascript:if(confirm('Confirm the deletion of this user?')) location='user_del.php?id=<?php echo $user['id']; ?>'">Delete</a>
                        </td>
						<?php endforeach ?>
                      </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php 
require 'footer.php';
?>
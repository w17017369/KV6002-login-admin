<?php

require '../db.func.php';
require '../toos.func.php';

$id = intval($_GET['id']);

$sql ="DELETE FROM fankui WHERE id = '$id'";
if(execute($sql)){
	setInfo('删除成功');
}else{
	setInfo('删除失败');
}
header('location:fankui.php');

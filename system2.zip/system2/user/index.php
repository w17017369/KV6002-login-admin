<?php 
require '../db.func.php';
require '../toos.func.php';
$prefix = getDBPregix();
session_start();
$id =$_SESSION['user']['id'];
$sql = "SELECT id,username,day,email,phone,created_at
        FROM {$prefix}user WHERE id={$id}";
		
	 // var_dump($sql);die;
$data=query($sql);
require 'header.php';





?>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title ">User</h4>
                  <p class="card-category"> User info</p>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead class=" text-primary">
                      <th>
                        ID
                      </th>
                      <th>
                        Username
                      </th>
					  <th>
					    Birthday
					  </th>
					  <th>
					    Email
					  </th>
					  <th>
					    Contact
					  </th>
                      <th>
                        Create time
                      </th>
                      </thead>
                      <tbody>
				<?php foreach($data as $admin):?>
                      <tr>
                        <td>
                          <?php echo $admin['id']; ?>
                        </td>
                        <td>
                          <?php echo $admin['username']; ?>
                        </td>
                        <td>
                           <?php echo $admin['day']; ?>
                        </td>
						<td>
						   <?php echo $admin['email']; ?>
						</td>
						<td>
						   <?php echo $admin['phone']; ?>
						</td>
                        <td>
                          <?php echo date('Y-m-d',$admin['created_time']); ?>
                        </td>
                      </tr>
					<?php endforeach; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
<?php
require 'footer.php';


?>
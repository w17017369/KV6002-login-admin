<?php 
require '../db.func.php';
require '../toos.func.php';

 $prefix = getDBPregix();
 session_start();
 $uid = $_SESSION['user']['id'];
 $sql = "SELECT id,price,quantity,uid,products,created_at,status
         FROM {$prefix}cart WHERE uid = {$uid} ORDER BY created_at DESC";
$orders=query($sql);

// Search by product ID Product name
function pro($id){
	$sql = "SELECT *
	         FROM cc_products WHERE id = {$id} ";
			 
	$pro=queryOne($sql);
	return $pro['name'];
}

require 'header.php';
?>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <div class="row">
                    <div class="col-12">
                      <h4 class="card-title ">Orders</h4>
                    </div>
                  </div>

                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead class=" text-primary">
                      <th>
                        ID
                      </th>
					  <th>
					    Name
					  </th>
                      <th>
                        Price
                  Amount
					  </th>
                      <th>
                        Order created time
                      </th>
					  <th>
					    Status
					  </th>
					  <th>
					    Operation
					  </th>
                      </thead>
                      <tbody>
						  <?php foreach($orders as $order): ?>
                      <tr>
                        <td>
                          <?php echo $order['id'];?>
                        </td>
						<td>
						  <?php echo pro($order['products']);?>
						</td>
                        <td>
                          <?php echo $order['price'];?>
                        </td>
						<td>
						  <?php echo $order['quantity'];?>
						</td>
                        <td>
                          <?php echo date('Y-m-d',$order['created_at']);?>
                        </td>
						<td>
							<?php
							 if($order['status'] == 0){
								 echo 'In Basket';
							 }else if($order['status'] == 1){
								 echo 'Payment pending';
							 }else if($order['status'] == 2){
								 echo 'Order';
							 }else if($order['status'] == 3){
								 echo 'Refund';
							 }
							 ?>
						</td>
						<td>
							<a href="edit_status.php?id=<?php echo $order['id'] ?>">Refund</a>
						</td>
                      </tr>
					  <?php endforeach ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php
    require 'footer.php';
    ?>
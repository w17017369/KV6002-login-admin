<?php 
require '../db.func.php';
require '../toos.func.php';

session_start();
$uid = $_SESSION['user']['id'];
 $sql = "SELECT id,uidcontent,create_time
         FROM fankui WHERE uid={$uid} ";
$liuyan=query($sql);
//查询用户姓名 
function findname($id){
	$sql = "select * from cc_user where id = {$id} ";
	$res = queryOne($sql);
	return $res['username'];
}
require 'header.php';
?>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <div class="row">
                    <div class="col-12">
                      <h4 class="card-title ">反馈列表</h4>
                      <p class="card-category"> 反馈管理</p>
					  <div class="col-2">
					  </div>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead class=" text-primary">
                      <th>
                        ID
                      </th>
                      <th>
                        反馈内容
                      </th>
                      <th>
                        留言用户
                      </th>
					  <th>
					    添加时间
					  </th>
					  <th>
					    操作
					  </th>
                      </thead>
                      <tbody>
						  <?php foreach($liuyan as $ly): ?>
                      <tr>
                        <td>
                          <?php echo $ly['id'];?>
                        </td>
						<td>
						  <?php echo $ly['content'];?>
						</td>
						<td>
						  <?php echo tname($ly['uid']);?>
						</td>
						
                        <td>
                          <?php echo date('Y-m-d',$ly['create_time']);?>
                        </td>
						<td>
						  <a href="fankui_del.php?id=<?php echo $ly['id'] ?>">删除</a> |
						</td>
                      </tr>
					  <?php endforeach ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php
    require 'footer.php';
    ?>
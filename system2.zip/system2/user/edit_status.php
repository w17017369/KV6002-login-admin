<?php

require '../db.func.php';
require '../toos.func.php';

$id = intval($_GET['id']);

$prefix = getDBPregix();
$sql = "UPDATE {$prefix}order 
	        SET status = '3',
			WHERE id = '$id'";
if(execute($sql)){
	echo "<script>javascript:alert('退款成功!');location.href='orders.php';</script>";
	exit;
}else{
	echo "<script>javascript:alert('退款失败!');location.href='orders.php';</script>";
	exit;
}

<?php
require '../db.func.php';
require '../toos.func.php';
if(!empty($_POST['username'])){
	$prefix = getDBPregix();
	
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	
	$sql="SELECT id ,username FROM  {$prefix}user 
	      WHERE username = '$username' AND password =  '$password' ";
		  
	$res = queryOne($sql);
	if($res){
		//Save session
		setSession('user',['username'=>$username,'id'=>$res['id']]);
		header('location:index.php');
	}else{
		setInfo('Incorrect username or password');
	}
}

?>
<!doctype html>
<html>

<head>
  <title>Shop</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="assets/css/googlefonts.css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.1" rel="stylesheet" />
</head>

<body>
  <div class="wrapper ">
    <div>
      <div>
        <div class="container" style="width: 50%;margin-top: 250px;">
          <div class="row">
            <div class="col-md-12">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Log in</h4>
                    <p class="card-category">Login to the backend as a user</p>
                  </div>
                  <div class="card-body">
					  <p><?php if(hasInfo()) echo getInfo()?></p>
                    <form action="login.php" method="post">
                      <div class="row">
                        <div class="col-md-12">
                          <div class="form-group">
                            <label class="bmd-label-floating">User Name</label>
                            <input type="text" name="username" value="" class="form-control">
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-12">
                          <div class="form-group">
                            <label class="bmd-label-floating">Password</label>
                            <input type="password" name="password" value="" class="form-control">
                          </div>
                        </div>
                      </div>
                      <button type="submit" class="btn btn-primary pull-right">Log in</button>
                      <div class="clearfix"></div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="assets/js/core/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
  <script src="assets/js/core/bootstrap-material-design.min.js"></script>
</body>

</html>
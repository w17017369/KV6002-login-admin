<?php

require '../db.func.php';
require '../toos.func.php';

$id = intval($_GET['id']);

$prefix = getDBPregix();
$sql ="DELETE FROM {$prefix}cart WHERE id = '$id'";

if(execute($sql)){
	setInfo('删除成功');
}else{
	setInfo('删除失败');
}
header('location:carts.php');

<?php 
require '../db.func.php';
require '../toos.func.php';
require 'auth.php';

$id = intval($_GET['id']);
if(empty($id)){
	header('location:users.php');
}
$prefix=getDBPregix();
$sql = "SELECT id,username,age,email,phone,code
        FROM {$prefix}user WHERE id = '$id'";
$current_user = queryOne($sql);
if(empty($current_user)){
	header('location:users.php');
}

if(!empty($_POST['code'])){
	$code = htmlentities($_POST['code']);
	$age = htmlentities($_POST['age']);
	$email = htmlentities($_POST['email']);
	$phone = htmlentities($_POST['phone']);
	if(strlen($phone) != 11 ){
				setInfo("Wrong mobile phone number format");
	}
	if(strlen($code!= 12 )){
				 setInfo("Incorrect format of student number");
	}
	$sql = "UPDATE {$prefix}user 
	        SET code = '$code',age = '$age',email='$email',phone='$phone'
			WHERE id = '$id'";
			// var_dump($sql);die;
    if(execute($sql)){
		$current_user = array_merge($current_user,$_POST);
		setInfo('Update successful');
	}else{
		setInfo('Update failed');
	}
	
}

require 'header.php';
?>
		<!-- End Navbar -->
		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header card-header-primary">
								<h4 class="card-title">Modify user</h4>
								<p class="card-category">Modify a user</p>
							</div>
							<div class="card-body">
								<p style="color: red;"><?php if(hasInfo())  echo getInfo();?></p>
								<form action="user_edit.php?id=<?php echo $id; ?>" method="post">
									<div class="row">
										<div class="col-md-12">
											<div class="form-group">
												<label class="bmd-label-floating">User Name</label>
												<input type="text" name="username"  value="<?php echo $current_user['username'] ?>" disabled class="form-control">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label class="bmd-label-floating">ID</label>
												<input type="text" name="code" value="<?php echo $current_user['code'] ?>" class="form-control">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="bmd-label-floating">Age</label>
												<input type="number" name="age" value="<?php echo $current_user['age'] ?>" class="form-control">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<div class="form-group">
												<label class="bmd-label-floating">Contact</label>
												<input type="text" name="phone" value="<?php echo $current_user['phone'] ?>" class="form-control">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<div class="form-group">
												<label class="bmd-label-floating">E-mail</label>
												<input type="email" name="email" value="<?php echo $current_user['email'] ?>" class="form-control">
											</div>
										</div>
									</div>
									<button type="submit" class="btn btn-primary pull-right">Update information</button>
									<div class="clearfix"></div>
								</form>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	<?php
	
	
	
	require 'footer.php';
	?>
<?php

require '../db.func.php';
require '../toos.func.php';

$id = intval($_GET['id']);

echo "<script language='javascript'>";
echo "window.confirm('Whether to confirm the deletion')";
echo "location.href='index.php'";
echo "</script>";

$prefix = getDBPregix();
$sql ="DELETE FROM {$prefix}user WHERE id = '$id'";

if(execute($sql)){
	setInfo('Deleted Successful');
}else{
	setInfo('Deleted Faileds');
}
header('location:users.php');


<?php
//数据库链接参数



date_default_timezone_set('PRC');
return [
	'DB_HOST' =>'127.0.0.1',
	'DB_PORT' =>'3306',
	'DB_USER' =>'root',
	'DB_PASS' =>'123456',
	'DB_NAME' =>'kv6002',
	'DB_PREFIX' =>'cc_',
	'DB_CHARSET'=>'utf8'
];


?>